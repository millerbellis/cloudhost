 // Initialize Firebase
 import firebase from 'firebase/app';
 import "firebase/auth";
 import "firebase/database";
 import "firebase/storage";
 
 
 var config = {
  apiKey: "AIzaSyCVrVWPADgegOnJhrIpYdLdh5vDF9sI2_E",
  authDomain: "trucking-9dbd7.firebaseapp.com",
  databaseURL: "https://trucking-9dbd7.firebaseio.com",
  projectId: "trucking-9dbd7",
  storageBucket: "trucking-9dbd7.appspot.com",
  messagingSenderId: "997770934193"
};
firebase.initializeApp(config);

  export default firebase;