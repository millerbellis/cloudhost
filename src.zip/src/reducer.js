import uuidv4 from 'uuid';

export default function reducer(state, action) {
    switch(action.type){
        case "SET_USER":
            return {
                ...state,
                user: action.payload.uid,
                name: action.payload.displayName
            }
       
        default: 
        return state;
    }
}