import React, {useState, useEffect, useContext} from 'react';
import firebase from '../firebase';
import {Helmet} from 'react-helmet';

export default function Register() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [userRef, setUserRef] = useState(firebase.database().ref("users"));

    const handleSubmit = event => {
        event.preventDefault()
       firebase
       .auth()
       .createUserWithEmailAndPassword(email, password)
       .then(createdUser => {
           createdUser.user
           .updateProfile({
               displayName: email
           })
           .then(() => {
                saveUser(createdUser).then(() => {
                console.log("user saved");
            })
           })
       })
       .catch(err => {
           console.error(err);
           setError(err);
       })
    }

    const saveUser = createdUser => {
        return userRef.child(createdUser.user.uid).set({
            name: createdUser.user.displayName,
            vendor: 0
        })
    }
    
    return(
        <>
<Helmet 
 title= "Cloudhost - Signup"
 meta={[
  {"name": "description", "content": "signup for Cloudhost - free project management software"},
  {property: "og:type", content: "article"},
  {property: "og:title", content: "Cloudhost - Signup"},
  {property: "og:url", content: "https://cloudhost.club/signup"}
 ]}
/>
        <div className="flex justify-center">

     <div className=" justify-center max-w-sm rounded  shadow-lg">
 
 <div className=" text-center px-6 py-4">
   <div className="font-bold text-xl mb-2">Sign up</div>
   <form onSubmit={handleSubmit} className="w-full max-w-xs">
   <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
        Email Address
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        type="text"
        onChange={event => setEmail(event.target.value)}
        placeholder="info@cloudhost.club"/>
    </div>
  </div>

  <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
        Password
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green" 
       type="password"
       onChange={event => setPassword(event.target.value)}
        placeholder="Password"/>
    </div>
  </div>
  <div className="md:flex md:items-center">
    <div className="md">
      <button style={{backgroundColor:'#00ffa9'}} className="shadow hover:bg-purple-light focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded" type="submit">
       Sign up
      </button>
    </div>
  </div>
   </form>
 </div>

</div>

</div>

       
</>
    )
}