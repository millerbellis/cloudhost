import React, {useState, useEffect, useContext, useReducer} from 'react';
import {
    Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem } from 'reactstrap';
  import TodosContext from '../context';
  import todosReducer from '../reducer';
  import firebase from '../firebase';
export default function NavBar() {
    const [isOpen, setNav] = useState(false);
    const toggle = () => {
        setNav(!isOpen)
      }
    const{state, dispatch, user, name} = useContext(TodosContext);
    const handleSignout = () => {
      firebase
          .auth()
          .signOut()
          .then(() => console.log("signed out!"));
    }
    return(
      <>
        <div className="shadow-md">
        <Navbar color="dark" dark expand="md">

     <NavbarBrand style={{color:'#00ffa9'}} href="/">CloudHost</NavbarBrand>
        
          
          <NavbarToggler onClick={toggle} />
          {user ? (
            <Collapse isOpen={isOpen} navbar>
            <Nav className="ml-auto" navbar>
            <NavItem>
                <NavLink href="/">Logged in as: <b>{name}</b></NavLink>
              </NavItem>
              <NavItem>
                <NavLink href="/">Projects</NavLink>
              </NavItem>
              <NavItem>
                <NavLink onClick={handleSignout} href="/">Logout</NavLink>
              </NavItem>
         
             
            </Nav>
          </Collapse>
          ): (
            <Collapse isOpen={isOpen} navbar>
            <Nav className="ml-auto" navbar>
              <NavItem>
                <NavLink href="/login">Login</NavLink>
              </NavItem>
              <NavItem>
                <NavLink href="/vendorlogin">Vendor Login</NavLink>
              </NavItem>
              <NavItem>
                <NavLink href="/vendorsignup">Vendor Signup</NavLink>
              </NavItem>
              <NavItem>
                <NavLink href="/signup">Signup</NavLink>
              </NavItem>
             
            </Nav>
          </Collapse>
          )}
         
        </Navbar>
      </div>

      </>
    )
}