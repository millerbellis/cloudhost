import React, {useState, useEffect, useContext} from 'react';
import {
    Collapse,
    Navbar,
    NavbarToggler,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink,
    UncontrolledDropdown,
    DropdownToggle,
    DropdownMenu,
    DropdownItem } from 'reactstrap';

export default function Home() {

    const [isOpen, setNav] = useState(false);

    const toggle = () => {
        setNav(!isOpen)
      }
    return(
      <>
       
    

      </>
    )
}