import React, {useState, useEffect, useContext, useReducer} from 'react';
import firebase from '../firebase';
import TodosContext from '../context';
import todosReducer from '../reducer';
import Home from './home';
import {Helmet} from 'react-helmet';

export default function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = event => {
        event.preventDefault()
       firebase
       .auth()
       .signInWithEmailAndPassword(email, password)
       .then(signedInUser => {
          
       })
       .catch(err => {
           console.error(err);
           setError(err);
       })
    }
    const{state, dispatch} = useContext(TodosContext);
    return(
        <>

        <Helmet 
 title= "Cloudhost - Login"
 meta={[
  {"name": "description", "content": "login for Cloudhost - free project management software"},
  {property: "og:type", content: "article"},
  {property: "og:title", content: "Cloudhost - Login"},
  {property: "og:url", content: "https://cloudhost.club/login"}
 ]}
/>
        <div className="flex justify-center">

     <div className=" justify-center max-w-sm rounded  shadow-lg">
 
 <div className=" text-center px-6 py-4">
      <TodosContext.Consumer>
      {value => <div className="font-bold text-xl mb-2">Login {value.user}</div>}
      </TodosContext.Consumer>
   
   <form onSubmit={handleSubmit} className="w-full max-w-xs">
   <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
        Email Address
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        type="text"
        value={email}
        onChange={event => setEmail(event.target.value)}
        placeholder="info@cloudhost.club"/>
    </div>
  </div>

  <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
        Password
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green" 
       type="password"
       value={password}
       onChange={event => setPassword(event.target.value)}
        placeholder="Password"/>
    </div>
  </div>
  <div className="md:flex md:items-center">
    <div className="md">
      <button style={{backgroundColor:'#00ffa9'}} className="shadow  hover:bg-purple-light focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded" type="submit">
       Login
      </button>
    </div>
  </div>
   </form>
 </div>

</div>

</div>

</>

    )
}