import React, {useState, useEffect, useContext, useReducer, usePrevious} from 'react';
import firebase from '../../firebase';
import TodosContext from '../../context';
import {Modal, ModalHeader, ModalBody, Card, Button, CardTitle, CardText, Row, Col, Label} from 'reactstrap';
export default function Projects() {
const{state, dispatch, user, name} = useContext(TodosContext);
const [urlParam, seturlParam] = useState('');
const [projRef, setProjRef] = useState(firebase.database().ref("projects"))


 useEffect(() => {
    getAll()
    const url = window.location.href;
      seturlParam((url.slice(window.location.href.indexOf('=') + 1)))

    
  }, [])

  const getAll = () => {
     let loads = []
      projRef.on("child_added", snap => {
          loads.push(snap.val())
        
        //loads.push(snap.val())
        // snap.forEach(function(child) {
        
        // // loads.push(child.val())
        // })
        //setProjs(loads)
        // setProjs(loads)
        // console.log(projs)
      })
      
  
  }

  
    return(
        <>
    {urlParam}

</>
    )
}