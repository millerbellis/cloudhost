import React, {useState, useEffect, useContext, useReducer, usePrevious} from 'react';
import firebase from '../../firebase';
import TodosContext from '../../context';
import {Modal, ModalHeader, ModalBody, Button,  Row, Col, Label, CardTitle, Card, Alert} from 'reactstrap';
import { Input, Image, Progress, Accordion, Icon } from 'semantic-ui-react'
import ProjId from './projid';
import mime from "mime-types";
import uuidv4 from 'uuid';
import {Helmet} from 'react-helmet';
export default function Projects() {
const{state, dispatch, user, name} = useContext(TodosContext);
const [modal, setModal] = useState(false);
const [modal1, setModal1] = useState(false);
const [projName, setProjname] = useState('');
const [vend, setVend] = useState('');
const [address, setAddress] = useState('');
const [userRef, setUserRef] = useState(firebase.database().ref("users"))
const [projRef, setProjRef] = useState(firebase.database().ref("projects"))
const [imgRef, setImgRef] = useState(firebase.database().ref("images"))
const [vendRef, setVendRef] = useState(firebase.database().ref("vendors"))
const [vendProjRef, setVendProjRef] = useState(firebase.database().ref("vendorsProjects"))
const [userid, setUserid] = useState('')
const [projs, setProjs] = useState([])
const [projid, setProjid] = useState('');
const [uploadState, setUploadState] = useState('')
const [uploadTask, setUploadTask] = useState(null)
const [storageRef, setStorageRef] = useState(firebase.storage().ref())
const [authorized, setAuthorized] = useState(["image/jpeg", "image/png", "image/pdf"])
const [file, setFile] = useState(null)
const [progress, setProgress] = useState(0)
const [images, setImages] = useState(null)
const [url, setUrl] = useState('')
const [imgs, setImgs] = useState([])
const [cprojs, setCprojs] = useState(false);
const [vendore, setVendore] = useState('');
const [ven, setVen] = useState([])
const [activeVendAdd, setActiveVendAdd] = useState(0)
const [activeVend, setActiveVend] = useState(0)
const [activeUpload, setActiveUpload] = useState(0)
const [users, setUsers] = useState([])
const [vendProjs, setVendProjs] = useState([])

 useEffect(() => {
    getAll()
    getAllImg()
    getAllVends()
    getAllUsers()
    getAllVendProjs()
  }, [])

  const getAll = () => {
     let loads = [];
      projRef.on("child_added", snap => {
          loads.push(snap.val());
        setProjs(loads)
    
     
      })
  }

  const getAllUsers = () => {
    let loads = [];

     userRef.on("child_added", snap => {
       loads.push(snap.val());
       setUsers(loads)
        
     })
 }

 const getAllVendProjs = () => {
  let loads = [];

   vendProjRef.on("child_added", snap => {
     loads.push(snap.val());
     setVendProjs(loads)
      
   })
}


  const getAllImg = () => {
    let load = [];
     imgRef.on("child_added", snap => {
      load.push(snap.val());
         setImgs(load)
      
     })

 }

 const getAllVends = () => {
  let loa = [];
   vendProjRef.on("child_added", snap => {
    loa.push(snap.val());
       setVen(loa)
       
   })

}

  const handlePageChange = (pageid) => {
     // alert(pageid)
      setModal1(!modal1)
    // //window.location = "/project/project=" + pageid;
     setProjid(pageid)
    
    // const url = window.location.href;
    // seturlParam((url.slice(window.location.href.indexOf('=') + 1)))
    
  }

  const toggles1 = () => {
    setModal1(!modal1)
}

  const toggles = () => {
      setModal(!modal)
  }
  const handleSubmit = event => {
    event.preventDefault();
    //alert(userid)
    const key = uuidv4()

    const response = {
        id: userid,
        projname: projName,
        numvend: vend,
        addof: address,
        child: key,
        complete: 0,
        sdate: firebase.database.ServerValue.TIMESTAMP,
        edate:''
    }
    projRef
    .push(response)
    .then(() => {
        let keys = [];
      projRef.limitToLast(1).on("child_added", snap => {
        keys.push(snap.key);
        
        const response = {
            child: snap.key
        }
       projRef
        .child(snap.key)
        .update(response)
       
    getAll()
      })


      
        setAddress('')
        setModal(false)
        setVend('')
        setProjname('')
       
    })
  }

  const handleUpdateSubmit = event => {
      event.preventDefault()

      let response = {};
      if(address) {
        response = {addof: address}
      } else if(vend) {
        response = {numvend: vend}
      } else if(projName){
        response = {projname: projName}
      }
    if(address && vend) {
        response = {addof: address, numvend: vend}
    }
    if(address && projName){
        response = {addof: address, projname: projName}
    }
    if(vend && projName){
        response = {numvend: vend, projname: projName}
    }
    if(vend && projName && address) {
        response = {addof: address, projname: projName, numvend: vend}
    }
     

   projRef
    .child(projid)
    .update(response)
   
    setModal1(!modal1)

    setAddress('')
    setModal(false)
    setVend('')
    setProjname('')
    getAll()
  }
 const handleChange = e => {
    if (e.target.files[0]) {
      const image = e.target.files[0];
      setImages(image);
    }
  }

 const handleUpload = () => {
   const uploadTask = firebase.storage().ref(`images/${projid}/${images.name}`).put(images);
    uploadTask.on('state_changed', 
    (snapshot) => {
      // progrss function ....
      const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
      setProgress(progress);
    }, 
    (error) => {
         // error function ....
      console.log(error);
    }, 
  () => {
      // complete function ....
      firebase.storage().ref('images').child(projid+"/"+images.name).getDownloadURL().then(url => {
          console.log(url);
          setUrl(url);
          createDbLine(url);
          setProgress(0)
       
      })
      .then(() => {
        let keys = [];
      imgRef.limitToLast(1).on("child_added", snap => {
        keys.push(snap.key);
        
        const response = {
            path: snap.key
        }
       imgRef
        .child(snap.key)
        .update(response)
     
   
      })
    })
  });

 const createDbLine = (urls) => {
      const response = {
          imagePath: urls,
          imgId: projid,
          path: ''
        }
      
        imgRef
          .push(response)
        
          
  }
}

const download = (imgp) => {
  // fake server request, getting the file url as response
  setTimeout(() => {
    const response = {
      file: imgp,
    };
    // server sent the url to the file!
    // now, let's download:
   
    window.open(response.file)
    // you could also do:
    // window.open(response.file);
  }, 100);
}

const completeProj = (pro) => {
  const response = {
   complete: 1,
   edate: firebase.database.ServerValue.TIMESTAMP
  }

  projRef
    .child(pro)
    .update(response)
    .then(() => {
      setModal1(false)
      getAll()
    })
}

const deletePhoto = (imgpath) => {
  let img = imgpath;
  console.log(img)
  //storage.ref().child(uid).child(img).delete()
  imgRef.child(img).remove()
  .then(() => {
    setModal1(false)
    window.location.reload()
  })
}

const handleVendorAdd = (proji) => {

  const response = {
    email: vendore
  }
  const response1 = {
    email: vendore,
    projid: proji
  }

  vendRef
    .push(response)
    .then(() => {
      setVendore('')
    })
  vendProjRef
    .push(response1)
    .then(() => {
      setVendore('')
    })
setVendore('')
}

    return(
        <>
         <Helmet 
 title= "Cloudhost - Projects"
 meta={[
  {"name": "description", "content": "project managent software"},
  {property: "og:type", content: "article"},
  {property: "og:title", content: "Cloudhost - Projects"},
  {property: "og:url", content: "https://cloudhost.club/projects"}
 ]}
/>
        <TodosContext.Consumer>
      {value => 
     <>
      <div>{users.map((us) => {
        return   <>
        {us.name === value.name && us.vendor === 0 ? (
             <>

             <button 
             onClick={toggles}
             style={{backgroundColor:'#00ffa9'}}
               className=" hover:bg-grey-lightest text-grey-darkest font-semibold ml-8 mt-3 py-2 px-4 border border-grey-light rounded shadow">
                   Add Project 
               </button>
               <button 
             onClick={() => setCprojs(!cprojs)}
             style={{backgroundColor:'#00ffa9'}}
               className=" hover:bg-grey-lightest text-grey-darkest font-semibold ml-8 mt-3 py-2 px-4 border border-grey-light rounded shadow">
                   Complete Projects
               </button>
             </>
        ): (
       ''
        )}
       
        </>
 })}</div>

  

 
 <div>{users.map((us) => {
        return   <>
        {us.name === value.name && us.vendor === 1 ? (
         <div>{projs.map((answer) => {
          return   <>
          
          {answer.complete === 0  ? (
            <div>{vendProjs.map((vend) => {
              return   <>
              {vend.projid === answer.child && vend.email === us.name ? (
                <Row className="mt-3 ml-3 mr-3 mb-3" >
                <Col sm="12" >
                  <Card body style={{boxShadow: '0px 5px 4px' , backgroundColor:'#35383d'}}>
                    <CardTitle style={{color:'white'}}><Label >Project Name: </Label> <b>{answer.projname}</b></CardTitle>
                    <CardTitle style={{color:'white'}}><Label >Project Address: </Label> <b>{answer.addof}</b></CardTitle>
         
                    <button 
        onClick={() => handlePageChange(answer.child)}
        style={{backgroundColor:'#00ffa9'}}
        className=" hover:bg-grey-lightest text-grey-darkest font-semibold  mt-3 py-2 px-4 border border-grey-light rounded shadow">
            View Project
        </button>
       
                  </Card>
                </Col>
          
              </Row>
              ): (
                ''
              )}
                
              </>
        })}</div>
          ) : (
            ''
          )}
            
        </>
        })}</div>
      //   </>
      // })}</div>
  ): (
    ''
     
     )}
     </>
})}</div>

   
  
        <Modal isOpen={modal} toggle={toggles}  style={{boxShadow: '0px 5px 4px'}}>
                <ModalHeader style={{backgroundColor:'#00ffa9'}} toggle={toggles}>Add a Project</ModalHeader>

                <ModalBody>
                <form onSubmit={handleSubmit} className="w-full max-w-xs">
                <div className="md:flex md:items-center mb-6">
                    <div className="md:w-1/2">
                    <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        type="text"
                        value={value.user}
                        hidden='true'
                        onChange={event => setUserid(value.user)}
                        />
                    <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
                        Project Name
                    </label>
                    </div>
                    <div className="md:w-2/2">
                    <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        type="text"
                        value={projName}
                        onChange={event => setProjname(event.target.value)}
                        placeholder="Project name.."/>
                    </div>
                </div>

                <div className="md:flex md:items-center mb-6">
                    <div className="md:w-1/2">
                    <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
                        # of Vendors
                    </label>
                    </div>
                    <div className="md:w-2/2">
                    <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        type="text"
                        value={vend}
                        onChange={event => setVend(event.target.value)}
                        placeholder="Number of vendors.."/>
                    </div>
                </div>

                <div className="md:flex md:items-center mb-6">
                    <div className="md:w-1/2">
                    <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" >
                        Address of Project
                    </label>
                    </div>
                    <div className="md:w-2/2">
                    <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        type="text"
                        value={address}
                        onChange={event => setAddress(event.target.value)}
                        placeholder="Address of project.."/>
                    </div>
                </div>
                <div className="items-stretch">
                    <div className="center">
                    <button style={{backgroundColor:'#00ffa9'}} onClick={event => setUserid(value.user)} className="shadow hover:bg-purple-light focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded" type="submit">
                    Add Project
                    </button>
                    </div>
                </div>
                </form>
        </ModalBody>

        </Modal>
        <div>{projs.map((answer) => {
        return <>
        {projid === answer.child ? (
           <Modal isOpen={modal1} toggle={toggles1}  style={{boxShadow: '0px 5px 4px'}}>
           <ModalHeader style={{backgroundColor:'#00ffa9'}} toggle={toggles1}>Project</ModalHeader>

           <ModalBody >
               <form onSubmit={handleUpdateSubmit}>
           <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
        Project Name
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        defaultValue={answer.projname}
        onChange={event => setProjname(event.target.value)}
      type="text"/>
   
    </div>
     </div>
     <div>{users.map((us) => {
        return   <>
        {us.name === value.name && us.vendor === 0 ? (
              
          <div className="md:flex md:items-center mb-6">
          <div className="md:w-1/3">
            <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
              Number of Vendors
            </label>
          </div>
          <div className="md:w-2/3">
            <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
              defaultValue={answer.numvend}
              onChange={event => setVend(event.target.value)}
            type="text"/>
         
          </div>
           </div>
        ) : (
            ''
        )}
           </>
})}</div>
    
     <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
        Address of project
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        defaultValue={answer.addof}
        onChange={event => setAddress(event.target.value)}
      type="text"/>
   
    </div>
     </div>
     <div className="md:flex md:items-center mb-6">
    <div className="md:w-1/3">
      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
        Start Date
      </label>
    </div>
    <div className="md:w-2/3">
      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
        defaultValue={Date(answer.sdate)}
        disabled={true}
      type="text"/>
   
    </div>
     </div>
        {answer.complete === 1 ? (
          <>
           <div className="md:flex md:items-center mb-6">
           <div className="md:w-1/3">
             <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
               Complete Date
             </label>
           </div>
           <div className="md:w-2/3">
             <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
               defaultValue={Date(answer.edate)}
               
             type="text"/>
          
           </div>
            </div>
            </>
        ) : (
          <>
           <div>{users.map((us) => {
        return   <>
        {us.name === value.name && us.vendor === 0 ? (
          <>
          <button 
          type="submit"
          style={{backgroundColor:'#00ffa9'}}
          className=" hover:bg-grey-lightest text-grey-darkest font-semibold  py-2 px-4 border border-grey-light rounded shadow">
                Update
          </button>
          <button 
          type="submit"
          onClick={() => completeProj(answer.child)}
          style={{backgroundColor:'#fc0025', marginLeft:'10px', color:'white'}}
          className=" hover:bg-grey-lightest text-grey-darkest font-semibold  py-2 px-4 border border-grey-light rounded shadow">
                Project Complete
          </button>
          </>
           ) : (
            ''
        )}
           </>
})}</div>
          </>
        )}
    
    </form>
{answer.complete === 1 ? (
  ''
) : (
    <div>{users.map((us) => {
        return   <>
        {us.name === value.name && us.vendor === 0 ? (
  <>

         
    <Row className="mt-3 ml-3 mr-3 mb-3" >
                  <Col sm="12" >
                 
                    <Card body style={{boxShadow: '0px 5px 4px'}}>
                    <i class="far fa-plus-square fa-2x" onClick={() => activeVendAdd === 1 ? (setActiveVendAdd(0)) : (setActiveVendAdd(1))}></i>
                    <CardTitle>Add Vendors</CardTitle>
                    {activeVendAdd === 1 ? (
                      <>
                    <div className="md:flex md:items-center mb-6">
                    <div className="md:w-1/3">
                      <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
                        Vendor Email
                      </label>
                    </div>
                    <div className="md:w-2/3">
                      <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
                        
                        onChange={event => setVendore(event.target.value)}
                      type="email"/>

                    </div>
                      </div>
                      
                        <button 
                        onClick={() => handleVendorAdd(answer.child)}
                        style={{backgroundColor:'#00ffa9'}}
                        className=" hover:bg-grey-lightest text-grey-darkest font-semibold py-2 px-4 border border-grey-light rounded shadow">
                              Add Vendor
                        </button>
                        
                      </>
                        
                                  
                    ): (
                      ''
                    )}
                   
        </Card>
                  </Col>
            
                </Row>

  <Row className="mt-3 ml-3 mr-3 mb-3" >
               <Col sm="12" >
                 <Card body style={{boxShadow: '0px 5px 4px'}}>
                 <i class="far fa-plus-square fa-2x" onClick={() => activeVend === 1 ? (setActiveVend(0)) : (setActiveVend(1))}></i>
                 <CardTitle>Vendors</CardTitle>
  <div>{ven.map((vend) => {
            return   <>
            {projid === vend.projid && activeVend === 1 ? (
                  
              
                 <div className="md:flex md:items-center mb-6">
               <div className="md:w-1/3">
               <label className="block text-grey font-bold md:text-right mb-1 md:mb-0 pr-4" for="inline-username">
               Vendor
               </label>
               </div>
               <div className="md:w-2/3">
               <input className="bg-grey-lighter appearance-none border-2 border-grey-lighter rounded w-full py-2 px-4 text-grey-darker leading-tight focus:outline-none focus:bg-white focus:border-green"
               defaultValue={vend.email}
               type="email"/>
 
               </div>
               </div>
 
                     
             
            ) : (
              ''
            )}
              
           </>
         })}</div>
          </Card>
               </Col>
 
               </Row>  
               


   

    <Row className="mt-3 ml-3 mr-3 mb-3" >
                  <Col sm="12" >
                    <Card body style={{boxShadow: '0px 5px 4px'}}>
                    <i class="far fa-plus-square fa-2x" onClick={() => activeUpload === 1 ? (setActiveUpload(0)) : (setActiveUpload(1))}></i>
                    <CardTitle>Upload an Image</CardTitle>
     {activeUpload === 1 ? (

       <>
 <br/>
        <input style={{color: "#00ffa9"}} type="file" onChange={handleChange}/>{''}
        <br/>
        <progress   value={progress} max="100"/>
        <br/>
        <button 
        onClick={handleUpload}
       style={{backgroundColor:'#00ffa9'}}
        className=" hover:bg-grey-lightest text-grey-darkest font-semibold  py-2 px-4 border border-grey-light rounded shadow">
             Upload
        </button>
        <br/>
       </>
     ) : (
       ''
     )}
     
        </Card>
                  </Col>
            
                </Row>


                </>
                 ) : (
                  ''
              )}
                 </>
      })}</div>
)}

   

      <div>{imgs.map((answer) => {
           return   <>
           {projid === answer.imgId ? (
                  <Row className="mt-3 ml-3 mr-3 mb-3" >
                  <Col sm="12" >
                    <Card body style={{boxShadow: '0px 5px 4px'}}>
                      <Image src={answer.imagePath}/>
        
                          <button 
        onClick={() => download(answer.imagePath)}
       style={{backgroundColor:'#00ffa9'}}
        className=" hover:bg-grey-lightest text-grey-darkest font-semibold  mt-3 py-2 px-4 border border-grey-light rounded shadow">
             View Image
        </button>
        <div>{users.map((us) => {
        return   <>
        {us.name === value.name && us.vendor === 0 ? (
  <>

        <button 
       onClick={() => deletePhoto(answer.path)}
       style={{backgroundColor:'#fc0025', color:'white'}}
        className=" hover:bg-grey-lightest text-grey-darkest font-semibold  mt-3 py-2 px-4 border border-grey-light rounded shadow">
             Delete Image
        </button>
            </>
        ) : (
          ''
        )}
        </>
        })}</div>
                    </Card>
                  </Col>
            
                </Row>
            
         

            
           ) : (
             ''
           )}
             
           </>
        })}</div>
              
 
   </ModalBody>

   </Modal> 
        )
        : (
        ''
        )}
         
        </>
        })}</div>




         {cprojs === false ? (
            <div>{projs.map((answer) => {
              return   <>
              {user === answer.id && answer.complete === 0 ? (
                    <Row className="mt-3 ml-3 mr-3 mb-3" >
                    <Col sm="12" >
                      <Card body style={{boxShadow: '0px 5px 4px' , backgroundColor:'#35383d'}}>
                        <CardTitle style={{color:'white'}}><Label >Project Name: </Label> <b>{answer.projname}</b></CardTitle>
                        <CardTitle style={{color:'white'}}><Label >Project Address: </Label> <b>{answer.addof}</b></CardTitle>
             
                        <button 
            onClick={() => handlePageChange(answer.child)}
            style={{backgroundColor:'#00ffa9'}}
            className=" hover:bg-grey-lightest text-grey-darkest font-semibold  mt-3 py-2 px-4 border border-grey-light rounded shadow">
                View Project
            </button>
           
                      </Card>
                    </Col>
              
                  </Row>
              
              ) : (
                ''
              )}
                
              </>
            })}</div>
        ): (
          ''
        )}


        {cprojs === true ? (
            <div>{projs.map((answer) => {
              return   <>
              {user === answer.id && answer.complete === 1 ? (
                    <Row className="mt-3 ml-3 mr-3 mb-3">
                    <Col sm="12" >
                      <Card body style={{boxShadow: '0px 5px 4px', backgroundColor:'#35383d'}}>
                        <CardTitle style={{color:'white'}}><Label >Project Name: </Label> <b>{answer.projname}</b></CardTitle>
                        <CardTitle style={{color:'white'}}><Label >Project Address: </Label> <b>{answer.addof}</b></CardTitle>
                              
                        <button 
            onClick={() => handlePageChange(answer.child)}
            style={{backgroundColor:'#00ffa9'}}
            className=" hover:bg-grey-lightest text-grey-darkest font-semibold  py-2 px-4 border border-grey-light rounded shadow">
                View Project
            </button>
                      </Card>
                    </Col>
              
                  </Row>
              
              ) : (
                ''
              )}
                
              </>
            })}</div>
        ): (
          ''
        )}
        



         
        </>
   
       
      }


      
        </TodosContext.Consumer>
</>

    )
}