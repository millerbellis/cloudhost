import React from 'react';
import { Input, Image, Progress, Accordion, Icon,Container, Header } from 'semantic-ui-react'
import {Helmet} from 'react-helmet';
export default function Caro() {
  return(
  <>
    <Helmet 
 title= "Cloudhost - Free Project Management Software"
 meta={[
  {"name": "description", "content": "Free project management software"},
  {property: "og:type", content: "article"},
  {property: "og:title", content: "Cloudhost - Free Project Management Software"},
  {property: "og:url", content: "https://cloudhost.club/"}
 ]}
/>
    <header class="header-area" id="header-area">
        <div class="dope-nav-container breakpoint-off">
            <div class="container">
                <div class="row">

                </div>
            </div>
        </div>
    </header>

    <section class="banner-section relative section-gap-full" id="banner-section">
        <div class="overlay overlay-bg"></div>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 banner-left">
                    <h1 class="text-uppercase">Hi, I'm Cloudhost</h1>
                    <p>The ultimate solution to handle all of your project management needs. </p>
                    <a class="video-btn primary-btn" href="/signup"><b>Sign up for free!</b></a>
                </div>
                <div class="col-md-6 banner-right text-center">
                    <Icon name='server' size='massive'/>
                </div>
            </div>
        </div>
        <div class="wave">
            <svg class="nectar-shape-divider" fill="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 300"
                preserveAspectRatio="none">
                <path d="M 1000 299 l 2 -279 c -155 -36 -310 135 -415 164 c -102.64 28.35 -149 -32 -232 -31 c -80 1 -142 53 -229 80 c -65.54 20.34 -101 15 -126 11.61 v 54.39 z"></path>
                <path d="M 1000 286 l 2 -252 c -157 -43 -302 144 -405 178 c -101.11 33.38 -159 -47 -242 -46 c -80 1 -145.09 54.07 -229 87 c -65.21 25.59 -104.07 16.72 -126 10.61 v 22.39 z"></path>
                <path d="M 1000 300 l 1 -230.29 c -217 -12.71 -300.47 129.15 -404 156.29 c -103 27 -174 -30 -257 -29 c -80 1 -130.09 37.07 -214 70 c -61.23 24 -108 15.61 -126 10.61 v 22.39 z"></path>
            </svg>
        </div>
    </section>
    {/* <section class="featured-section">
        <div class="container">
            <div class="section-title">
                <h2 class="text-center">As Featured In</h2>
            </div>
            <div class="row align-item-center">
                <div class="col-lg-3 col-md-6 col-sm-6 single-logo">
                    <img class="img-fluid" src="img/logo/logo1.png" alt=""/>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 single-logo">
                    <img class="img-fluid" src="img/logo/logo2.png" alt=""/>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 single-logo">
                    <img class="img-fluid" src="img/logo/logo3.png" alt=""/>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 single-logo">
                    <img class="img-fluid" src="img/logo/logo4.png" alt=""/>
                </div>
            </div>
        </div>
    </section> */}

     <section class="about-section section-gap-full relative" id="about-section">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-6 col-md-12 about-left">
                <i class="fas fa-rocket fa-10x"></i>
                
                </div>
                <div class="col-lg-5 col-md-7 about-right">
                    <h3>What Is Cloudhost?</h3>
                    <h1>The best free web app for project management ever!</h1>
                    <ul>
                        <li class="d-flex">
                         
                            <div class="details">
                                <h4>Feature Full</h4>
                                <p>
                                   Cloudhost comes packed full of features to keep projects moving on pace and on target!
                                </p>
                            </div>
                        </li>
                        <li class="d-flex">
                        
                            <div class="details">
                                <h4>Premium Quality</h4>
                                <p>
                                    Cloudhost is the premium quality web app for all project management, plus its free.
                                </p>
                            </div>
                        </li>
                        <li class="d-flex">
                            
                            <div class="details">
                                <h4>Excellent Support</h4>
                                <p>
                                    We have the highest class of support ready and available to assist you with anything!
                                </p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="floating-shapes">
            <span data-parallax='{"x": 150, "y": -20, "rotateZ":500}'>
                <img src="img/shape/fl-shape-1.png" alt=""/>
            </span>
            <span data-parallax='{"x": 250, "y": 150, "rotateZ":500}'>
                <img src="img/shape/fl-shape-2.png" alt=""/>
            </span>
            <span data-parallax='{"x": -180, "y": 80, "rotateY":2000}'>
                <img src="img/shape/fl-shape-3.png" alt=""/>
            </span>
            <span data-parallax='{"x": -20, "y": 180}'>
                <img src="img/shape/fl-shape-4.png" alt=""/>
            </span>
            <span data-parallax='{"x": 300, "y": 70}'>
                <img src="img/shape/fl-shape-5.png" alt=""/>
            </span>
            <span data-parallax='{"x": 250, "y": 180, "rotateZ":1500}'>
                <img src="img/shape/fl-shape-6.png" alt=""/>
            </span>
            <span data-parallax='{"x": 180, "y": 10, "rotateZ":2000}'>
                <img src="img/shape/fl-shape-7.png" alt=""/>
            </span>
            <span data-parallax='{"x": 60, "y": -100}'>
                <img src="img/shape/fl-shape-9.png" alt=""/>
            </span>
            <span data-parallax='{"x": -30, "y": 150, "rotateZ":1500}'>
                <img src="img/shape/fl-shape-10.png" alt=""/>
            </span>
        </div>
    </section>

     <section class="feature-section section-gap-full" id="feature-section">
        <div class="container">
            <div class="row align-items-center feature-wrap">
                <div class="col-lg-4 header-left">
                    <h1>
                        An exceptionally unique experience to you
                    </h1>
                    <a class="primary-btn" href="/signup"><b>Signup</b><br/>
                    <i class="fas fa-user-plus"></i>
                    </a>
                </div>
                <div class="col-lg-8">
                    <div class="row features-wrap">
                        <div class="col-md-6">
                            <div class="single-feature relative">
                                <div class="overlay overlay-bg"></div>
                             
                                <h3>Awesome Design</h3>
                                <p>
                                    We incorporated great design in this app to allow a great user experience!
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="single-feature relative">
                                <div class="overlay overlay-bg"></div>
                                
                                <h3>For all</h3>
                                <p>
                                    This app has been created for everyone in mind! Don't like it? Let us know!
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="single-feature relative">
                                <div class="overlay overlay-bg"></div>
                            
                                <h3>Constant Updates</h3>
                                <p>
                                    We updated our web app weekly to ensure a great experience and to ensure our app is filled with features you would normally have to pay for
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="single-feature relative">
                                <div class="overlay overlay-bg"></div>
                               
                                <h3>Full Use</h3>
                                <p>
                                    You get full use of the app for free, we don't limit functionallity to free accounts.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="price-section section-gap-full" id="price-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 price-left">
                    <h4>
                        Our Pricing Plan and Options
                    </h4>
                    <p>
                       We offer the best pricing solutions to fit any personal or business needs.
                    </p>
                </div>
                <div class="col-lg-7 d-flex price-right">
                    <div class="single-price main">
                        <div class="top-wrap">
                        <i class="fas fa-briefcase"></i>
                            <h4>Free</h4>
                            <p>For Personal Use</p>
                            <h2><span>$</span>0.00</h2>
                        </div>
                        <div class="bottom-wrap">
                            <ul>
                                <li class="d-flex justify-content-between align-items-center">
                                    <span>As many vendors as you have for projects</span>
                                    <i class="fas fa-check"></i>
                                </li>
                                <li class="d-flex justify-content-between align-items-center">
                                    <span>As many projects as you have!</span>
                                    <i class="fas fa-check"></i>
                                </li>
                                <li class="d-flex justify-content-between align-items-center">
                                    <span>Encrypted security</span>
                                    <i class="fas fa-check"></i>
                                </li>
                                <li class="d-flex justify-content-between align-items-center">
                                    <span>Lifetime Support</span>
                                    <i class="fas fa-check"></i>
                                </li>
                            </ul>
                            <a href="/signup" class="primary-btn primary-btn-w d-block mx-auto">Select Plan</a>
                        </div>
                    </div>
                    <div class="single-price">
                        <div class="top-wrap">
                        <i class="fas fa-building"></i>
                            <h4>Enterprise</h4>
                            <p class="relative">For Enterprises</p>
                            <h2 class="relative"><span>$</span>10 per month</h2>
                        </div>
                        <div class="bottom-wrap">
                            <ul>
                                <li class="d-flex justify-content-between align-items-center">
                                    <span>As many vendors as you have!</span>
                                    <i class="fas fa-check"></i>
                                </li>
                                <li class="d-flex justify-content-between align-items-center">
                                    <span>As many projects as you have!</span>
                                    <i class="fas fa-check"></i>
                                </li>
                                <li class="d-flex justify-content-between align-items-center">
                                    <span>Encrypted security</span>
                                    <i class="fas fa-check"></i>
                                </li>
                                <li class="d-flex justify-content-between align-items-center">
                                    <span>Lifetime Support</span>
                                    <i class="fas fa-check"></i>
                                </li>
                            </ul>
                            <a href="/signup" class="primary-btn d-block mx-auto">Select Plan</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </section>

  </>
  )
}