import React from 'react'

const TodosContext = React.createContext({
    user: [
       
    ]
});

export default TodosContext;